<img height="70px" src="https://raw.githubusercontent.com/Radon-Games/Radon-Games/main/src/assets/banner.svg"></img>

An open-source unblocked games website built with simplicity in mind.

## Setup
```
git clone https://github.com/Radon-Games/Radon-Games
cd Radon-Games
npm ci
git submodule update --init --recursive
npm run build
npm start
```
